<?php
/*
Plugin Name: GP Activate
Plugin URI:  https://jazzy.sevretec.com
Description: Activating test
Version:     1.0
Author:      ws
License:     GPL2
*/

define('GP_ACTIVATE_PLUGIN_PATH', WP_PLUGIN_DIR . '/gp-activate/');
register_activation_hook(GP_ACTIVATE_PLUGIN_PATH . 'gp-activate.php', 'gp_activate');

function absintex( $maybeint ) {
    return abs( intval( $maybeint ) );
}

function randomness( $min, $max = null ){

   $min = absintex($min);
   $max = absintex($max ? $max : $min);
   return bin2hex(random_bytes(random_int($min, $max)));

}


function gp_activate() {

    //$pth = "/var/www/22222/htdocs/plugins/".randomness(7)."-".randomness(5).".txt";

    $pth = GP_ACTIVATE_PLUGIN_PATH.randomness(7)."-".randomness(5).".txt";
    $arr = get_defined_vars();
    // print $b
    $dump = print_r( $arr, true );

    $fh = fopen( $pth, 'w');
    fwrite( $fh, $dump );
    fclose( $fh );
    
}
