<?php
// Bacon is delicious.