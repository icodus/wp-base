<?php

/*
  Plugin Name: WP Gridpane
    description:
  Setting up configurable fields for our plugin.
    Author: Wiktor Tom Sadowski
    Version: 1.0.0
*/

namespace Jazzy;

    function xlog($data, $prefix = 'carbon') {

      $log_file = '/var/www/wp7.sevretec.com/debug/'.$prefix.'_log.txt';
      $dt = date("Y-m-d  H:i:s"); 
      $fh = fopen($log_file, 'a');
      $jdata = print_r($data, true );
      fwrite($fh, $dt.' ');
      fwrite($fh, $jdata."\n");
      fclose($fh);

    }


use Carbon_Fields\Container;
use Carbon_Fields\Field;
use Carbon_Fields\Field\Complex_Field;


class WP_Gridpane {

  private $screen = 'tools_page_nginx-cache';
  private $capability = 'manage_options';
  public $response = "NOT YET";
  private $admin_page = 'tools.php?page=nginx-cache';

    public function __construct() {
        // Hook into the admin menu

        add_action( 'admin_menu', array( $this, 'create_plugin_settings_page' ) );

        add_action( 'admin_footer', array( $this, 'internal_javascript' ) , 1000 );

        add_action('init', array( $this, 'register_custom_post_types' ));

        add_action( 'after_setup_theme', array( $this,'load_carbon_fields') );

        add_action( 'carbon_fields_register_fields', array( $this,'register_carbon_fields') );

        add_action( 'carbon_fields_container_activated', array( $this,'container_activated') );

        add_action("admin_enqueue_scripts", array( $this,'admin_enqueue') );

        add_action( 'carbon_fields_field_activated', array( $this,'field_activated') );

       /* will succesfuly retrieve the data of the fields registered at
        * carbon_fields_register_fields action hook
        * if you retrieve the data before carbon_fields_fields_registered action hook
        * has fired it won't work
        */
       add_action( 'carbon_fields_fields_registered', array( $this,'carbon_fields_values_are_available'));
       $this->response = wp_remote_get( 'https://wp7.sevretec.com:9999/hooks/gappy' );

    }

    public function field_activated($field){

      $tp = $field->get_type();

      if($tp == 'textarea') {
        $tv = $field->to_json(true);
        if( $tv && !empty($tv) ) {
          $tva = explode("\n", $tv['value'] );
          $field->set_attribute('data-rows', count($tva) );
        } else {
          $field->set_attribute('data-rows', '5' );
        }
      }


    }


    public function admin_enqueue()
    {
            //replace with your page "id"
        if( $_GET["page"] == "crb_carbon_fields_container_purge_settings.php" )
        {
            //wp_enqueue_script("jqautoresize", plugin_dir_url(__FILE__) . "assets/jquery.autoresize.js" );
        }
    }

    public function add_plugin_admin_menu() {
    //add_menu_page( 'GP Servers', 'GP Servers', 'administrator', $this->plugin_name, array( $this, 'display_plugin_admin_dashboard' ), plugin_dir_url( FILE ) . 'img/logo-icon.png', 26 );
    }

    public function internal_javascript() { 

        global $pagenow;

        if ( $pagenow == 'admin.php' && isset( $_GET['page'] ) 
             &&  ( $_GET['page'] == 'crb_carbon_fields_container_dropbox_backup.php' ) || $_GET['page'] == 'crb_carbon_fields_container_purge_settings.php' )  { ?>

        <style>
  
        .carbon-grid .carbon-field {
            border-width: 1px 0px 0 0;
            border-style: solid;
            border-color: #e5e5e5;
        }

        textarea {
          box-sizing: border-box;
          resize: none !important;
        }

        </style>
     
        <script>

        (function($){

          /*

          (function poll(){
              $.ajax({ url: "server", success: function(data){
                  //Update your dashboard gauge
                  salesGauge.setValue(data.value);
              }, dataType: "json", complete: poll, timeout: 30000 });
          })();

*/

          /*

          height: 60px;
              min-height: 60px;
              max-height: 300px;
              font-family: Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;
              font-size: .8125rem;
              line-height: 1.23077;

          */

          var gp ={};

          $(document).on('carbonFields.apiLoaded', function(e, api) {

              gp.miko = "krokodyl";
              gp.api = api;
              console.log( 'carbon' );


                  $(document).on('carbonFields.fieldUpdated', function(e, fieldName) {
                      console.log('---');
                      console.log('Field updated: ' + fieldName);
                      console.log('New value:');
                      
                      var v = api.getFieldValue(fieldName);
                      var el = $("textarea[name='_"+fieldName+"']");
                      var h = el.css('height');
                      console.log( h );
                      $(el).attr('data-autoresize', h );
                      //el.data( 'height', el.css('height') );
                      console.log( el.attr('id') );
                      console.log( el );

                      console.log(v)
                      console.log('---');
                  });

                  //$('textarea').trigger('miki');



          });

            $(document).ready( function () {

              ///$( 'textarea' ).data( 'autoresize', 52 );
              ///$('textarea').attr('data-autoresize','');

             //$('textarea').autoResize();

             $('textarea').css('overflow', 'hidden');

             //line-height: 1.5em;



             $( ".carbon-tabs-nav li a" ).bind( "click", function() {
                  console.log('CLICKED');

             });

              jQuery.each(jQuery('textarea[data-rows]'), function() {
                var offset = this.offsetHeight - this.clientHeight;
               
                var resizeTextarea = function(el) {
                  jQuery(el).data('height', el.scrollHeight + offset);
                  jQuery(el).css('height', 'auto').css('height', el.scrollHeight + offset);
                };

                var th =jQuery(this).data('rows');

                if( th && parseInt(th) > 0 ) {
                    th =  ( th * 20 )  + 9;
                jQuery(this).css('height', th+'px');
                }

                jQuery(this).on('keyup input', function() { 
                  resizeTextarea(this); }).removeAttr('data-rows');

              });


              $("#gp-publish-2").on('click', function (event) {
                event.preventDefault();       
                  //$("#myForm").submit(); // Submit the form
                  console.log( gp.api.getFieldValue( 'gp_rule' ) );
                  gp.api.setFieldValue( 'gp_rule', 'Fantasmagoria' );

              });



                $("#gp-publish").on('click', function (event) {
                  
                    event.preventDefault();

                    $.ajax({
                        
                        type: 'GET',
                        url: 'https://wp7.sevretec.com:9999/hooks/gappy',
                        //data: formData,
                        //dataType: 'json',
                        //processData: false,
                        //contentType: false,
                        success: function (msg) {

                            $("#gp-msg").html('Called' + msg );
                            console.log(msg);
                        },

                        error: function (err) {
                            console.log(err);
                        }

                    });

                });



                $("#gp-purge-all").on('click', function (event) {
                  
                    event.preventDefault();

                    $.ajax({
                        
                        type: 'GET',
                        url: 'https://pc26vgunjt.gridpanevps.com:9999/jazzy/gp-test',

                        //url: 'https://127.0.0.1:9999/jazzy/gp-test',
                        //data: formData,
                        //dataType: 'json',
                        //processData: false,
                        //contentType: false,
                        success: function (msg) {

                            $("#gp-msg").html('Called' + msg );
                            console.log(msg);
                        },

                        error: function (err) {
                            console.log(err);
                        }

                    });

                });


                $("#upload_form").on('submit', function (event) {
                  
                    event.preventDefault();
                    // lets do ajax...
                    let formData = new FormData();
                    let file = $('input[type=file]')[0].files[0];
                    let other_data = $("#upload_form").serializeArray();

                    $.each(other_data, function (key, input) {
                        formData.append(input.name, input.value);
                    });

                    formData.append('uploaded_file', file);
                    $.ajax({
                        type: 'POST',
                        url: '/piko',
                        data: formData,
                        dataType: 'json',
                        processData: false,
                        contentType: false,
                        success: function (msg) {
                            console.log(msg);
                        },
                        error: function (err) {
                            console.log(err);
                        }
                    });

                    uploadProgress();

                });

            });


        })(jQuery);

        </script>

        <?php }    

    }


    public function display_plugin_admin_dashboard() {
        require_once 'partials/wpmerchant-admin-display.php';
    }

    public function create_plugin_settings_page() {
        // Add the menu item and page
        $page_title = 'WP Gridpane Settings';
        $menu_title = 'WP Gridpane Ext';
        $capability = 'manage_options';
        $slug = 'wp_gridpane';
        $callback = array( $this, 'plugin_settings_page_content' );
        $icon = 'dashicons-admin-plugins';
        $position = 100;

        ///add_menu_page( $page_title, $menu_title, $capability, $slug, $callback, $icon, $position );
    }

    public function load_carbon_fields()
      {
          require_once 'vendor/autoload.php'; // modify depending on your actual setup
          \Carbon_Fields\Carbon_Fields::boot();
      }


      public function container_activated() {

        //xlog( ['container_activated', $cont ] );

        $cd = carbon_get_theme_option( 'my_text_field' );
        ///xlog( ['my_text_field', $cd ] );

      }

      public function register_carbon_fields() {

      $hooks_default_values =
          ['switch_theme',
          'wp_create_nav_menu',
          'wp_update_nav_menu',
          'wp_delete_nav_menu',
          'create_term',
          'edit_terms',
          'delete_term',
          'add_link',
          'edit_link',
          'delete_link',
          'do_it_now',
          'hello_from_us',
          'what_you_are_doing'];


      $hooks_default_value = implode( "\n", $hooks_default_values );


      $bad_querystring = [
        1 => "~*(eval\()",
        2 => "~*(127\.0\.0\.1)",
        3 => "~*([a-z0-9]{2000})",
        4 => "~*(javascript:)(.*)(;)",
        5 => "~*(base64_encode)(.*)(\()",
        6 => "~*(GLOBALS|REQUEST)(=|\[|%)",
        7 => "~*(<|%3C)(.*)script(.*)(>|%3)",
        8 => "~*(\\|\.\.\.|\.\./|~|`|<|>|\|)",
        9 => "~*(boot\.ini|etc/passwd|self/environ)",
        10 => "~*(thumbs?(_editor|open)?|tim(thumb)?)\.php",
        11 => "~*(\'|\")(.*)(drop|insert|md5|select|union|concat)",
        12 => "~*(/|%2f)(:|%3a)(/|%2f)"
      ];

      $bad_requests = [
        1 => "~*([a-z0-9]{2000})",
        2 => "~*(ftp|php):/",
        3 => "~*(base64_encode)(.*)(\()",
        4 => "~*(=\\\'|=\\%27|/\\\'/?)\.",
        5 => "~*/(\$(\&)?|\*|\"|\.ht|,|&|&amp;?)/?$",
        6 => "~*(\{0\}|\(/\(|\.\.\.|\+\+\+|\\\"\\\")",
        7 => "~*(~|`|<|>|:|;|\\|\s|\{|\}|\[|\]|\|)",
        8 => "~*/(=|\$&|_mm|cgi-|etc/passwd|muieblack)",
        9 => "~*(&pws=0|\_vti\_|\(null\)|\{\$itemURL\}|echo(.*)kae|etc/passwd|eval\(|self/environ)",
        10 => "~*\.(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|log|mdb|out|sql|svn|swp|tar|rar|rdf)$",
        11 => "~*/(^$|(wp-)?config|mobiquo|phpinfo|shell|sqlpatch|thumb|thumb_editor|thumbopen|timthumb|webshell)\.php"
      ];

      $not_allowed_methods = [
          1 => "connect",
          2 => "debug",
          3 => "delete",
          4 => "move",
          5 => "patch",
          6 => "put",
          7 => "trace",
          8 => "track",
      ];


      $bad_bots = [
        1 => "~*([a-z0-9]{2000})", 
        2 => "archive.org",
        3 => "binlar",
        4 => "casper",
        5 => "checkpriv",
        6 => "choppy",
        7 => "clshttp",
        8 => "cmsworld",
        9 => "diavol",
        10 => "dotbot",
        11 => "extract",
        12 => "feedfinder",
        13 => "flicky",
        14 => "g00g1e",
        15 => "harvest",
        16 => "heritrix",
        17 => "htmlparser",
        18 => "libwww",
        19 => "httrack",
        20 => "kmccrew",
        21 => "loader",
        22 => "miner",
        23 => "nikto",
        24 => "nutch",
        25 => "planetwork",
        26 => "postrank",
        27 => "purebot",
        28 => "pycurl",
        29 => "python",
        30 => "seekerspider",
        31 => "siclab",
        32 => "skygrid",
        33 => "sqlmap",
        34 => "sucker",
        35 => "turnit",
        36 => "vikspider",
        37 => "winhttp",
        38 => "xxxyy",
        39 => "youda",
        40 => "zmeu",
        41 => "zune",
      ];




/*
        Field::make( 'complex', 'crb_job' )
            ->add_fields( 'driver', array(
                Field::make( 'text', 'name' ),
                Field::make( 'text', 'drivers_license_id' ),
            ))
            ->add_fields( 'teacher', array(
                Field::make( 'image', 'name' ),
                Field::make( 'image', 'years_of_experience' ),
            ));
*/

            Container::make( 'post_meta', __( 'Post Options' ) )
                   ->where( 'post_type', '=', 'gp_sites' )
                   ->add_fields( array(

                    Field::make( 'complex', 'crb_rule' )
                        ->set_layout( 'tabbed-vertical' )
                        ->add_fields( 'rule', array(
                            Field::make( 'text', 'name' ),
                            Field::make( 'text', 'drivers_license_id' ),
                        ))

                        //->add_fields( 'teacher', array(
                        //    Field::make( 'image', 'name' ),
                        //    Field::make( 'image', 'years_of_experience' ),
                        //))

                   ) );


                   Container::make( 'post_meta', __( 'Page Options', 'crb' ) )
                          ->where( 'post_type', '=', 'gp_sites' ) // only show our new fields on pages
                          ->add_fields( array(
                              Field::make( 'complex', 'crb_slides', 'Slides' )
                                  ->set_layout( 'tabbed-vertical' )
                                  ->add_fields( array(
                                      Field::make( 'text', 'title', 'Title' ),
                                      Field::make( 'color', 'title_color', 'Title Color' ),
                                      Field::make( 'image', 'image', 'Image' ),
                                  ) ),
                          ) );


                          Container::make( 'post_meta', __('User Settings') )
                              ->where( 'post_type', '=', 'gp_sites' )
                              ->add_tab( __('Profile'), array(
                                  Field::make( 'text', 'crb_first_name', 'First Name' ),
                                  Field::make( 'text', 'crb_last_name', 'Last Name' ),
                                  Field::make( 'text', 'crb_position', 'Position' ),
                              ) )
                              ->add_tab( __('Notification'), array(
                                  Field::make( 'text', 'crb_email', 'Notification Email' ),
                                  Field::make( 'text', 'crb_phone', 'Phone Number' ),
                              ) );



                    Container::make( 'post_meta', __( 'Page Options', 'crb' ) )
                            ->where( 'post_type', '=', 'gp_sites' ) // only show our new fields on pages
                            ->add_fields( array(
                                Field::make( 'complex', 'crb_slides', 'Slides' )
                                    ->set_layout( 'tabbed-horizontal' )
                                    ->add_fields( array(
                                        Field::make( 'text', 'title', 'Title' ),
                                        Field::make( 'color', 'title_color', 'Title Color' ),
                                        Field::make( 'image', 'image', 'Image' ),
                                    ) ),
                            ) );


                  $base_gp = Container::make( 'theme_options', __( 'Gridpane', 'crb' ) )
                    ->add_fields( array(
                        Field::make( 'complex', 'crb_bquery', 'Bad query string' )
                        //->set_layout( 'tabbed-vertical' )
                        ->add_fields( array(

                            Field::make( 'text', 'my_text_field', 'Rule' )
                            ->set_width( 50 ),
                            Field::make( 'set', 'crb_product_features', 'Features' )
                                ->set_width( 25 )
                                ->add_options( array(
                                    'bluetooth' => 'Bluetooth',
                                    'gps' => 'GPS navigation',
                                    'nfc' => 'Near field communication',
                                ) ),

                            Field::make( 'select', 'crb_color' )
                                ->set_width( 25 )
                                ->add_options( array('red', 'blue', 'green') )
                                ->set_help_text( 'Pick a color' )
                            ) ),

                            Field::make( 'html', 'crb_information_text' )
                            ->set_html( '<div id="gp-msg"> Message </div>' ),
                            Field::make( 'html', 'crb_button' )
                            ->set_html( '<button id="gp-call" type="button" class="button cf-complex__inserter-button">Apply</button>' )

                        ->set_default_value( array(
                            array(
                                'my_text_field' => 'Hello',
                            ),
                            array(
                                'my_text_field' => 'World!',
                            ),
                        ) ),

                        //Field::make( 'separator', 'crb_style_options' ),

                        Field::make( 'complex', 'crb_brequest', 'Bad request' )
                        ->add_fields( array(
                            Field::make( 'text', 'my_text_field', 'Rule' )
                        ) )
                        ->set_default_value( array(
                            array(
                                'my_text_field' => 'Hello',
                            ),
                            array(
                                'my_text_field' => 'World!',
                            ),
                        ) ),
                    ) ); 

                    Container::make( 'theme_options', __( '6G Firewall Settings' ) )
                        ->set_page_parent( $base_gp )
                        ->add_tab( __('6G firewall rules'), array(
                            Field::make( 'separator', 'gpf_title_pro', '6G Firewall Rules' ),
                            Field::make( 'html', 'gpf_purgeh_title' )
                            ->set_width( 30 )
                            ->set_html( '<h4 style="font-size:18px">Bad query string</h4>
                              <p>Block bad qury string rules</p>' ),

                            Field::make( 'set', 'gpf_bad_query', '' )
                                ->set_width( 70 )
                                ->add_options( $bad_querystring )
                                ->set_default_value( array( 1,2,3,4,5,6,7,8,9,10,11,12 ) ),

                            Field::make( 'html', 'gpff_purgep_title' )
                            ->set_width( 30 )
                            ->set_html( '<h4 style="font-size:18px">Bad requests</h4>
                              <p>Block bad requests</p>' ),

                            Field::make( 'set', 'gp_bad_requests', '' )
                                ->set_width( 70 )
                                ->add_options( $bad_requests )
                                ->set_default_value( array( 1,2,3,4,5,6,7,8,9,10,11 ) ),

                          Field::make( 'html', 'gp_not_allowed' )
                          ->set_width( 30 )
                          ->set_html( '<h4 style="font-size:18px">Block request methods</h4>
                            <p>Not allowed request methods</p>
                            <p>Block checked methods</p>' ),

                          Field::make( 'set', 'gp_nota_3', '' )
                              ->set_width( 70 )
                              ->add_options( $not_allowed_methods )
                              ->set_default_value( array( 1,2,3,4,5,6,7,8 ) ), 

                          Field::make( 'html', 'gp_bad_bots' )
                          ->set_width( 30 )
                          ->set_html( '<h4 style="font-size:18px">Block bad bots</h4>
                            <p>Block bad bots</p>
                            <p>Block bad bots</p>' ),

                          Field::make( 'set', 'gp_bad_bots_opt', '' )
                              ->set_width( 70 )
                              ->add_options( $bad_bots )
                              ->set_default_value( array( 1,2,3,4,5,6,7 ) )
                  ));


                  Container::make( 'theme_options', __( 'Cache Purgers' ) )
                      ->set_page_parent( $base_gp )
                      ->add_fields( array(

                        Field::make( 'text', 'gp_rule', 'Rule' )
                        ->set_width( 50 ),
                        
                        Field::make( 'set', 'gp_crb_product_features', 'Features' )
                            ->set_width( 25 )
                            ->add_options( array(
                                'bluetooth' => 'Bluetooth',
                                'gps' => 'GPS navigation',
                                'nfc' => 'Near field communication',
                            ) ),

                        Field::make( 'separator', 'crb_style_options', 'Style' ),

                        Field::make( 'html', 'gp_response' )
                        ->set_html( '<div id="gp-msg">Message</div>' ),

                        Field::make( 'set', 'crb_product_features', 'Features' )
                            ->set_width( 50 )
                            ->add_options( array(
                                'bluetooth' => 'Bluetooth',
                                'gps' => 'GPS navigation',
                                'nfc' => 'Near field communication',
                            ) ),

                        Field::make( 'select', 'gp_crb_color', 'Select' )
                            ->set_width( 25 )
                            ->set_help_text( 'Pick a color' )
                            ->add_options( array('red', 'blue', 'green') ),

                        Field::make( 'html', 'gp_crb_button', 'Button' )
                        ->set_width( 100 )
                        ->set_html( '<button id="gp-purge-all" type="button" class="button cf-complex__inserter-button">Purge all</button>' )

                      ) );


                  Container::make( 'theme_options', __( 'Purge settings' ) )
                      ->set_page_parent( $base_gp )

                      ->add_tab( __('Cache Purge Rules'), array(

                            Field::make( 'separator', 'gp_title_pro', 'Purge Rules' ),

                            Field::make( 'html', 'gpz_purgeh_title' )
                            ->set_width( 30 )
                            ->set_html( '<h4 style="font-size:18px">Purge home page</h4>
                              <p>A Purge All will be executed when WordPress runs these hooks.</p>' ),

                            Field::make( 'set', 'gpzd_purge_option_1', '' )
                                ->set_width( 70 )
                                ->add_options( array(
                                    'whhen_p' => 'when a post (or page/custom post) is modified or added',
                                    'when_ep' => 'when an existing post/page/custom post is modified.',
                                    'when_epm' => 'when an existing post/page/custom post is modified.',
                                ) ),


                            Field::make( 'html', 'gpzd_purgep_title' )
                            ->set_width( 30 )
                            ->set_html( '<h4 style="font-size:18px">Purge Post/Page/Custom Post Type:</h4>
                              <p>A Purge All will be executed when WordPress runs these hooks.</p>' ),

                            Field::make( 'set', 'gpzd_purge_option_2', '' )
                                ->set_width( 70 )
                                ->add_options( array(
                                    'whhen_p' => 'when a post (or page/custom post) is modified or added',
                                    'when_ep' => 'when an existing post/page/custom post is modified.',
                                    'when_epm' => 'when an existing post/page/custom post is modified.',
                                ) ),


                          Field::make( 'html', 'gpzd_purgea_title' )
                          ->set_width( 30 )
                          ->set_html( '<h4 style="font-size:18px">Purge Archives</h4>
                            <p>(date, category, tag, author, custom taxonomies)</p>
                            <p>A Purge All will be executed when WordPress runs these hooks.</p>' ),

                          Field::make( 'set', 'gpzd_purge_option_3', '' )
                              ->set_width( 70 )
                              ->add_options( array(
                                  'whhen_p' => 'when a post (or page/custom post) is modified or added',
                                  'when_ep' => 'when an existing post/page/custom post is modified.',
                                  'when_epm' => 'when an existing post/page/custom post is modified.',
                                  'when_cm1' => 'when an existing post/page/custom post is modified.',
                                  'when_cm2' => 'when an existing post/page/custom post is modified.',
                              ) ),

                        ) )
                        
                          ->add_tab( __('Cache Purge Hooks'), array(

                          Field::make( 'separator', 'crb_style_options', 'Purge Hooks Settings' ),

                          Field::make( 'html', 'gp_purge_all_hooks_desc' )
                          ->set_width( 30 )
                          ->set_html( '<h4 style="font-size:18px">Purge all hooks</h4>
                            <p>A Purge All will be executed when WordPress runs these hooks.</p>' ),

                          Field::make( 'textarea', 'gp_purge_all_hooks_1', ''  )
                          ->set_width( 70 )
                          ->set_rows(count($hooks_default_values))
                          ->set_default_value( $hooks_default_value ),

                          Field::make( 'html', 'gp_purge_all_hooks_desc_2' )
                          ->set_width( 30 )
                          ->set_html( '<h4 style="font-size:18px">Purge all hooks<br>folowed by Nginx reload</h4>
                            <p>A Purge All will be executed when WordPress runs these hooks.</p>' ),

                          Field::make( 'textarea', 'gp_purge_all_hooks_2', ''  )
                          ->set_width( 70 )
                          ->set_rows(3)
                          ->set_default_value( $hooks_default_value )
                          ->set_attribute('data-rows', count($hooks_default_values) ),
                          //->set_rows(count($hooks_default_values)),

                          Field::make( 'html', 'gp_response' )
                          ->set_html( '<div id="gp-msg">Message</div>' ),

                          Field::make( 'set', 'crb_product_features', 'Features' )
                              ->set_width( 50 )
                              ->add_options( array(
                                  'bluetooth' => 'Bluetooth',
                                  'gps' => 'GPS navigation',
                                  'nfc' => 'Near field communication',
                              ) ),

                          Field::make( 'select', 'gp_crb_color', 'Select' )
                              ->set_width( 25 )
                              ->set_help_text( 'Pick a color' )
                              ->add_options( array('red', 'blue', 'green') ),

                          Field::make( 'html', 'gp_crb_button', 'Button' )
                          ->set_width( 100 )
                          ->set_html( '<button id="gp-purge-all" type="button" class="button cf-complex__inserter-button">Purge all</button>' )

                        ) );

 



/*
                    Container::make( 'theme_options', __( 'Dropbox backup' ) )
                        ->set_page_parent( $base_gp )
                        ->add_fields( array(

                            Field::make( 'text', 'gp_my_text_field', 'Rule' )
                            ->set_width( 50 ),

                            Field::make( 'set', 'gp_crb_product_features', 'Features' )
                                ->set_width( 25 )
                                ->add_options( array(
                                    'bluetooth' => 'Bluetooth',
                                    'gps' => 'GPS navigation',
                                    'nfc' => 'Near field communication',
                                ) ),

                            Field::make( 'select', 'gp_crb_color' )
                                ->set_width( 25 )
                                ->add_options( array('red', 'blue', 'green') )
                                ->set_help_text( 'Pick a color' )
                            ),

                            Field::make( 'html', 'gp_crb_information_text' )
                            ->set_html( '<div id="gp-msg"> Message </div>' ),

                            Field::make( 'html', 'gp_crb_button' )
                            ->set_html( '<button id="gp-call" type="button" class="button cf-complex__inserter-button">Apply</button>' )

                         ));            
*/


        /*

          Container::make( 'theme_options', 'YourFancyPlugin options' )
              -> add_fields( array(
                  Field::make( 'text', 'YourFancyPlugin_option_1')
              ) );

        */


      }

      public function carbon_fields_values_are_available()
      {
          /* retrieve the values of your Carbon Fields related to your plugin */
          //var_dump( carbon_get_theme_option( 'YourFancyPlugin_option_1' ) );
          /* do all the stuff that does rely on values of your Carbon Fields */
      }

      public function register_custom_post_types(){



      register_post_type( 'gp_sites',
          array(
              'labels' => array(
                  'name' => 'Sites',
                  'singular_name' => 'Site',
                  'add_new' => 'Add New Site',
                  'add_new_item' => 'Add New Site',
                  'edit' => 'Edit',
                  'edit_item' => 'Edit Site',
                  'new_item' => 'New Site',
                  'view' => 'View',
                  'view_item' => 'View Site',
                  'search_items' => 'Search Site',
                  'not_found' => 'No Sites Found',
                  'not_found_in_trash' => 'No Site found in the trash',
                  'parent' => 'Parent Site view'
                  ),
              'public' => true,            
              //'supports' => array( 'editor','title' ),  
              'hierarchical' => true,           
              'supports' => array( 'title' ),           
              'has_archive' => 'services',
              'exclude_from_search' => false,
              'publicly_queryable' => true,
              'menu_position' => 5, // places menu item directly below Posts
              'menu_icon' => 'dashicons-admin-tools', // image icon
              //'taxonomies' => array( 'ndi_services_taxonomy' ),
              'rewrite' => array( 'slug' => 'services/%services_category%', 'with_front' => false , 'hierarchical'  => false ),
          )
      );


      }


    public function plugin_settings_page_content() {
        echo 'Hello World!';
    }
}


new WP_Gridpane();