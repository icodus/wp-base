<?php
namespace Jazzy\DB;
/**
 * Database Functions
 */

if( ! defined( 'ABSPATH' ) ) {
    return;
}

/**
 * Get all users from a database
 * @return array 
 */
function get_users() {
    // Perform a database call to get users
    return array();
}